# Brick by Brick 2024 Challenge - NaiveBaes Team

This is the NaiveBaes Team's solution documentation for the *Brick by Brick 2024* Challenge on AIcrowd.  

Challenge link: [Brick by Brick 2024 AIcrowd](https://www.aicrowd.com/challenges/brick-by-brick-2024)

## Getting Started

### Environment & Packages
Our experiments were conducted on a device with an Intel(R) Core(TM) i7-12700H 2.30 GHz processor, **32 GB of RAM**, and an Nvidia 1060 GPU with 6 GB of VRAM. Each experiment run required a total of **100 GB of free disk space**.

We used **Python 3.9**, along with the following key packages, which can be installed using:

```
pip install -r requirements.txt
```

### Data Preparation
Run the following command to download raw train and test data, and our pre-extracted features:

```
python download_dataset.py
```

This will generate the following directories:

1. **`input_raw_train_data/`**:
   - `train_X_v0.1.0.zip`: Raw signals for each training sample, downloaded from [AICrowd](https://www.aicrowd.com/challenges/brick-by-brick-2024/dataset_files).
   - `train_y_v0.1.0.csv`: Labels for each training sample, also available on [AICrowd](https://www.aicrowd.com/challenges/brick-by-brick-2024/dataset_files).

2. **`input_raw_test_data/`**:
   - `test_X_v0.1.0.zip`: Raw signals for each testing sample, downloaded from [AICrowd](https://www.aicrowd.com/challenges/brick-by-brick-2024/dataset_files).

3. **Feature Extraction Directories**:
   - `train_data_extract/` and `test_data_extract/`: Contain feature-extracted public train and test datasets.

**Alternative options**

1. If you already have the raw train and test data on your machine, you can move the files as described in 1. and 2. of the list above, and the `download_dataset.py` will skip downloading if the files already exist.

2. If you want to start from the raw data and test our feature extraction pipeline, please prepare the files as described in 1. and 2. of the list above and follow steps in **Feature Extraction** phase below.

**NOTICE**: The data downloaded from google drive are only the extracted feature from the provided train and test data. We prepare them only for saving time. We did not involve any external or extra dataset for training our models.

### Feature Extraction
<!-- **(Optional for public training and test datasets from AICrowd.)** -->

A feature extraction pipeline producing a feature-extracted public train set and test set.

**(Optional for public training and test datasets from AICrowd.)**

**(Skip 1. and 2. if you already ran `download_dataset.py` and don't want to test the feature extraction pipeline)**



(**NOTICE**) If you have previously downloaded the pre-computed feature-extracted train and test sets, running steps 1 and 2 will replace any existing files in the output folder.

1. Extract features from the public training dataset:

   ```
   python prepare_train_data.py --train_zip_path './input_raw_train_data/train_X_v0.1.0.zip' \
                                --train_label_path './input_raw_train_data/train_y_v0.1.0.csv' \
                                --output_dir './train_data_extract'
   ```
   *Processing time: ~11 hours (depends on the device).*

2. Extract features from the public test dataset:

   ```
   python prepare_test_data.py --test_zip_path './input_raw_test_data/test_X_v0.1.0.zip' \
                               --output_dir './test_data_extract'
   ```
   *Processing time: ~22 hours (depends on the device).*

**(Required for other/hidden/secret test datasets)**

Run below if you have another secret or holdout test set to generate the feature extracted format for prediction.

3. Extract features from another test dataset:

   ```
   python prepare_test_data.py --test_zip_path './input_raw_other_test_data/[filename].zip' \
                               --output_dir './other_test_data_extract'
   ```
Depends on the size of the dataset. It approximately takes 25 minutes per 31839 raw timeseries .pkl files for each feature row calculated, or around **0.047 sec per file**. 

For example: training set takes 25 minutes x 31839 pkl files x 28 csv files generated x 0.047 = ~11 hours.

### Complete Training and Inference Pipeline

**NOTICE: Ensure you have the following before proceeding:**

- [x] Feature-extracted **public train dataset**: `./train_data_extract/data_features_fix/`
- [x] Feature-extracted **test dataset**:
  - Public test dataset: `./test_data_extract/data_features_fix/`, 

  OR
  
  - Another test dataset: `./other_test_data_extract/data_features_fix/`

If the required files are missing, refer to the **Data Preparation** and **Feature Extraction** section.

To run the complete training and prediction pipeline:

#### **For Public Test Dataset (AICrowd)**
```
python main.py config/pipeline.yaml
```

#### **For Other/Secret Unreleased Dataset**

Ensure that the **feature-extracted secret test dataset path** inside `pipeline_custom.yaml` is correct. 

```
python main.py config/pipeline_custom.yaml
```

This process will produce models and prediction files in the following structure:

```
./logs/ensemble/base_ensemble/  # Logs and results
│
├── rf/                         # Random Forest models and predictions
│   ├── models/                 # Model checkpoints
│   │   ├── tier_0_fold_0.pkl
│   │   ├── tier_0_fold_1.pkl
│   │   ├── tier_1_fold_0.pth
│   │   └── ...
│   │
│   ├── test_predictions/       # Test predictions
│   │   ├── tst_preds_0.csv
│   │   └── ...  
│
├── xgb/                        # XGBoost models and predictions
│   ├── models/
│   │   ├── tier_0_fold_0.pkl
│   │   ├── tier_0_fold_1.pkl
│   │   ├── tier_1_fold_0.pth
│   │   └── ...
│   │
│   ├── test_predictions/
│   │   ├── tst_preds_0.csv
│   │   └── ...
│
./final_submission_file/
│
└── final_submission.csv.gz  # Ensembled results for submission
```

**Estimated completion time:** ~2.3 hours on the specified device.

#### **Predicting on a New Test Dataset (After Training the Models)**
If you have already trained the models and only need to make predictions on a new test dataset:

```
python main.py config/pipeline_custom.yaml --skip_train --model_dir "./logs/ensemble/base_ensemble"
```

Ensure that the **feature-extracted test dataset path** inside `pipeline_custom.yaml` is correct. 

If the **feature-extracted test dataset path** is not available, refer to the **Feature Extraction** section.

## Project Structure
```
download_dataset.py         # Download raw & processed public datasets
prepare_train_data.py       # Process raw public train data into feature-extracted train dataset
prepare_test_data.py        # Process raw public/secret test data into feature-extracted test dataset
main.py                     # Main training and inference script
config/                     # Configuration files for model and data
ensemble/                   # Core module for the model pipeline
│
├── data/                   # Data processing functions (normalization, feature crossing, tier labeling)
│
├── model/                  # Model training and prediction functions
│
├── pipeline.py             # Full data processing, training, validation, and prediction pipeline
│
└── probability_ensemble.py # Ensemble model aggregating predictions from different models
```

## Acknowledgments
This project utilizes [TSFEL](https://github.com/fraunhoferportugal/tsfel), which is licensed under the BSD-3-Clause license.


## Fixes
We found that we missed out using one of the augmented training set and we end up using 27x train sets instead of 28x as reported in the documentation after the competition ends. We will leave it for future work to validate the performance of complete 28x train sets augmentations.