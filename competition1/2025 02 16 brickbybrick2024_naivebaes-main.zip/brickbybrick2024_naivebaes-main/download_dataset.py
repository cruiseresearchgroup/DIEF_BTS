import os
import subprocess
import shutil
import requests
import gdown
import zipfile

#input API
os.system("aicrowd login --api-key 6c7b3d8b6624e3edb81225215228d158")

challenge_name = "brick-by-brick-2024"

# Run AIcrowd CLI command to list files
files_to_download = {
    "test_X_v0.1.0.zip": "1",
    "train_X_v0.1.0.zip": "2",
    "train_y_v0.1.0.csv": "3"
}

# List dataset files (dry-run)
print("Checking available dataset files...")
subprocess.run(["aicrowd", "dataset", "list", "-c", challenge_name])

# Check and download missing files
for file_name, file_index in files_to_download.items():
    if not os.path.exists(file_name):  # Only download if the file is missing
        print(f"Downloading {file_name}...")
        subprocess.run(["aicrowd", "dataset", "download", "-c", challenge_name, file_index])
    else:
        print(f"Skipping {file_name}, already exists.")

files_to_move1 = ["train_X_v0.1.0.zip", "train_y_v0.1.0.csv"]
destination_folder1 = "./input_raw_train_data"

# Create the destination folder if it doesn't exist
os.makedirs(destination_folder1, exist_ok=True)

# Move files only if they are not already in the destination
for file in files_to_move1:
    source_path = os.path.join(".", file)  # Current directory
    dest_path = os.path.join(destination_folder1, file)
    
    if os.path.exists(source_path):  # Check if file exists in current directory
        if not os.path.exists(dest_path):  # Only move if not already there
            shutil.move(source_path, dest_path)
            print(f"Moved: {file} → {destination_folder1}")
        else:
            print(f"Skipped (already exists): {file} in {destination_folder1}")
    else:
        print(f"File not found: {file}")
        
files_to_move2 = ["test_X_v0.1.0.zip"]
destination_folder2 = "./input_raw_test_data"

# Create the destination folder if it doesn't exist
os.makedirs(destination_folder2, exist_ok=True)

# Move files only if they are not already in the destination
for file in files_to_move2:
    source_path = os.path.join(".", file)  # Current directory
    dest_path = os.path.join(destination_folder2, file)
    
    if os.path.exists(source_path):  # Check if file exists in current directory
        if not os.path.exists(dest_path):  # Only move if not already there
            shutil.move(source_path, dest_path)
            print(f"Moved: {file} → {destination_folder2}")
        else:
            print(f"Skipped (already exists): {file} in {destination_folder2}")
    else:
        print(f"File not found: {file}")
        

        
#download data
# File details
files = {
    #"train_data_features.zip": "1l4phA-S9ZaVDjld3WCX7YaufJF26_JF3",
    "train_data_features.zip": "1vTIN0tjw0-972oTeuWWqXwNrxK19aPmN",
    "test_data_features.zip": "1E1CCHB5tjLCuv2atV0KRqIvx9lAbEhKd"
}

# Destination directories
dest_folders = {
    "train_data_features.zip": r"./train_data_extract/data_features_fix",
    "test_data_features.zip": r"./test_data_extract/data_features_fix"
}

# Check and download files
for filename, file_id in files.items():
    # Check if file exists
    if os.path.exists(filename):
        print(f"{filename} already exists. Skipping download.")
    else:
        url = f"https://drive.google.com/uc?id={file_id}"
        print(f"Downloading {filename}...")
        gdown.download(url, filename, quiet=False)

    # Extract ZIP if not already extracted
    folder = dest_folders[filename]
    if not os.path.exists(folder):
        os.makedirs(folder, exist_ok=True)
        print(f"Created directory: {folder}")
    
    # Extract the ZIP file if no files are present
    if not os.listdir(folder):  # If the folder is empty
        print(f"Extracting {filename} to {folder}...")
        with zipfile.ZipFile(filename, 'r') as zip_ref:
            zip_ref.extractall(folder)
            print(f"Extraction complete for {filename}.")
    else:
        print(f"Files already exist in {folder}, skipping extraction.")