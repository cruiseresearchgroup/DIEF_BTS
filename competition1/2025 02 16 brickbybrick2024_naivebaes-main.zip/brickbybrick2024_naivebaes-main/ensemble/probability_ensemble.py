import os
import pandas as pd
import numpy as np
from tqdm import tqdm
from typing import List
from zipfile import ZipFile
#from ensemble.config.paths import PATHS
from ensemble.config.labels import LABEL_TIERS, LABEL_NAMES
from ensemble.model.predictor import get_test_agg, get_stacked_res, post_processing


def level_split(preds: pd.DataFrame) -> List[pd.DataFrame]:
    """
    Args:
        preds (pd.DataFrame): prediction for one dataset, contains all tiers

    Returns:
        pred_list (List[pd.DataFrame]): a list of prediction of the dataset for each tier
    """
    col_tiers = [[] for _ in range(LABEL_TIERS)]
    for col in list(preds.columns):
        col_tiers[int(col[-1])].append(col)

    # Each entry in the pred_list 
    preds_list = []
    for cols in col_tiers:
        split_pred = preds[cols]
        split_pred = split_pred.rename(columns={col: col[:-2] for col in split_pred.columns})
        preds_list.append(split_pred)

    return preds_list


def check_pred_num(_final_res, thr=0.5):
    # Exclude 'filename' column if it exists
    filtered_df = _final_res.drop(columns=['filename'], errors='ignore')

    return (filtered_df >= thr).sum(axis=1)


def aggregate(pred_list: List[pd.DataFrame], filenames: list, weights=None):
    if weights != None:
        raise NotImplementedError
    
    dataset_preds = [[] for _ in range(LABEL_TIERS)]
    for preds in tqdm(pred_list, desc=f"Aggregating"):
        preds_tier_split = level_split(preds)
        for i, preds_tier in enumerate(preds_tier_split):
            dataset_preds[i].append(preds_tier)

    level_pred_list = get_test_agg(dataset_preds)
    stacked_res = get_stacked_res(level_pred_list)

    final_res = post_processing(stacked_res, LABEL_NAMES, filenames)

    return final_res


def ensemble_final_result(prob_prediction_paths: dict, test_zip_path: str,  output_base: str):
    """
    Ensemble all models test predictions
    """
    zipftest = ZipFile(test_zip_path, 'r')
    listtestfile = list(zipftest.namelist()[1:])

    prediction_list = []
    for k, paths in prob_prediction_paths.items():
        for p in tqdm(paths, desc=f"Loading {k} results:"):
            prediction_list.append(pd.read_csv(p))
    
    final_res = aggregate(prediction_list, listtestfile)

    print(f"Number of predicted labels statistics")
    print(check_pred_num(final_res).value_counts())

    # UPDATE THE OUTPUT CSV PATH. THIS CAN BE DIRECTLY SUBMITTED.
    final_res.to_csv("./final_submission_file/final_submission.csv.gz", index=False, compression='gzip')
